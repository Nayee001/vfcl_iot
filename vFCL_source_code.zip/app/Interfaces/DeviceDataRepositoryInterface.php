<?php

namespace App\Interfaces;

interface DeviceDataRepositoryInterface
{
    public function update_device_data($deviceData);
}
