<?php

namespace App\Interfaces;

interface DeviceLogsRepositoryInterface
{
    public function create($message);
}
