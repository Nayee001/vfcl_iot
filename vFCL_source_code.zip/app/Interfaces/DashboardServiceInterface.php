<?php

namespace App\Interfaces;

interface DashboardServiceInterface
{

}
