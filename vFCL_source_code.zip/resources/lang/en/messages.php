<?php
return [
    'error' => "Something Wrong Happen !!",
    'no_msg' => "No data or messages available for this device.",
    "no_device" => "No device is currently assigned to this user."
];
?>
