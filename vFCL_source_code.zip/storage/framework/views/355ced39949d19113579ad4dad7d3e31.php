<?php $__env->startSection('content'); ?>
    <!-- Content wrapper -->
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Account Settings /</span> Account</h4>

            <div class="row">
                <div class="col-md-12">
                    <ul class="nav nav-pills flex-column flex-md-row mb-3">
                        <li class="nav-item">
                            <a class="nav-link active" href="javascript:void(0);"><i class="bx bx-user me-1"></i> Account</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('change-password', Auth::user()->id)); ?>"><i
                                    class='bx bxs-lock-open'></i>
                                Change Password</a>
                        </li>
                        
                    </ul>

                    <div class="card mb-4">
                        <h5 class="card-header">Profile Details</h5>
                        <!-- Account -->
                        
                        <hr class="my-0" />
                        <div class="card-body">
                            <form id="form-users-edit" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="fname" class="form-label">First Name <?php echo dynamicRedAsterisk(); ?></label>
                                        <?php echo Form::text('fname', $user['fname'], [
                                            'placeholder' => 'First Name',
                                            'id' => 'fname',
                                            'class' => 'form-control',
                                        ]); ?>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="lname" class="form-label">Last Name <?php echo dynamicRedAsterisk(); ?></label>
                                        <?php echo Form::text('lname', $user['lname'], [
                                            'placeholder' => 'Last Name',
                                            'id' => 'lname',
                                            'class' => 'form-control',
                                        ]); ?>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="email" class="form-label">E-mail <?php echo dynamicRedAsterisk(); ?></label>
                                        <?php echo Form::text('email', $user['email'], ['placeholder' => 'Email', 'id' => 'email', 'class' => 'form-control']); ?>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="title" class="form-label">Title <?php echo dynamicRedAsterisk(); ?></label>
                                        <?php echo Form::text('title', $user['title'], [
                                            'placeholder' => 'Title; Professor, Research Assistant, etc..',
                                            'class' => 'form-control',
                                            'id' => 'title',
                                        ]); ?>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label" for="phoneNumber">Phone Number <?php echo dynamicRedAsterisk(); ?></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">US (+1)</span>
                                            <?php echo Form::tel('phonenumber', $user['phonenumber'], [
                                                'placeholder' => '123 456 7890',
                                                'class' => 'form-control',
                                                'id' => 'phonenumber',
                                            ]); ?>

                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="role" class="form-label">Role</label>
                                        <?php echo Form::select('roles', $roles, $userRole, [
                                            'class' => 'form-control',
                                            'id' => 'roles',
                                            'placeholder' => 'Select Role',
                                            disabledIfNotSuperAdmin(),
                                        ]); ?>

                                    </div>
                                </div>
                                <div class="mt-2">
                                    <button type="submit" id="submit"
                                        class="submit btn btn-primary me-2">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- /Account -->
                    </div>

                    
                </div>
            </div>
        </div>
        <!-- / Content -->
    </div>
    <!-- Content wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/pages-account-settings-account.js')); ?>"></script>
    <script>
        // User deactivation
        $(document).ready(function() {
            $('#form-users-deactivation').on('submit', function(e) {
                e.preventDefault();
                e.stopPropagation();
                $('submit').attr('disabled', true);
                var formData = new FormData($('#form-users-deactivation')[0]);
                $.ajax({
                    method: 'post',
                    url: '<?php echo e(route('user-deactivate', $user->id)); ?>',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    cache: false,
                    processData: false,
                    contentType: false,
                    success: function(resp) {
                        if (resp.code == '<?php echo e(__('statuscode.CODE200')); ?>') {
                            let timerInterval
                            Swal.fire({
                                title: resp.Message,
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                                    Swal.showLoading()
                                    const b = Swal.getHtmlContainer().querySelector(
                                        'b')
                                    timerInterval = setInterval(() => {
                                        b.textContent = Swal.getTimerLeft()
                                    }, 100)
                                },
                                willClose: () => {
                                    clearInterval(timerInterval)
                                }
                            })
                            setTimeout(function() {
                                location.reload();
                            }, 1900);
                        } else {
                            toastr.error(resp.Message);
                        }
                    },
                    error: function(data) {
                        $(".submit").attr("disabled", false);
                        var errors = data.responseJSON;
                        $.each(errors.errors, function(key, value) {
                            var ele = "#" + key;
                            $(ele).addClass('errors');
                            $('<label class="error">' + value + '</label>')
                                .insertAfter(ele);
                        });
                    }
                });
            });

            $('#form-users-edit').on('submit', function(e) {
                e.preventDefault();
                e.stopPropagation();
                $('submit').attr('disabled', true);
                var formData = new FormData($('#form-users-edit')[0]);
                $.ajax({
                    method: 'POST',
                    url: '<?php echo e(route('users.update', $user->id)); ?>',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    cache: false,
                    processData: false,
                    contentType: false,
                    success: function(resp) {
                        if (resp.code == '<?php echo e(__('statuscode.CODE200')); ?>') {
                            toastr.success(resp.Message);
                            setTimeout(function() {
                                location.reload();
                            }, 1900);
                        } else {
                            toastr.error(resp.Message);
                        }
                    },
                    error: function(data) {
                        $(".submit").attr("disabled", false);
                        var errors = data.responseJSON;
                        $.each(errors.errors, function(key, value) {
                            var ele = "#" + key;
                            $(ele).addClass('errors');
                            var parentInputGroup = $(ele).closest('.input-group-merge');

                            if (parentInputGroup.length > 0) {
                                $('<label class="error">' + value + '</label>')
                                    .insertAfter(
                                        parentInputGroup);
                            } else {
                                $('<label class="error">' + value + '</label>')
                                    .insertAfter(ele);
                            }
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\iot_web\iot_web\resources\views/user_settings/account_settings.blade.php ENDPATH**/ ?>