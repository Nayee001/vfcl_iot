<!-- Footer -->
<footer class="content-footer footer bg-footer-theme py-3">
    <div class="container-xxl d-flex flex-wrap justify-content-between align-items-center">
        <div class="col-12 col-md-6 mb-2 mb-md-0 text-center text-md-start">
            <span>© <script>document.write(new Date().getFullYear());</script> <?php echo e(env("APP_NAME")); ?>.</span>
            <span>All rights reserved.</span>
        </div>
        <div class="col-12 col-md-6 text-center text-md-end">
            <a href="javascript:void(0);" class="footer-link me-3">Privacy Policy</a>
            <a href="javascript:void(0);" class="footer-link me-3">Terms of Service</a>
            <a href="javascript:void(0);" class="footer-link">Contact Us</a>
        </div>
    </div>
</footer>
<!-- / Footer -->
<?php /**PATH C:\wamp64\www\iot_web\iot_web\resources\views/navigation/footer.blade.php ENDPATH**/ ?>