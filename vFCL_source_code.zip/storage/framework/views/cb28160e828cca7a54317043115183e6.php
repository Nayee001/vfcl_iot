<!-- Content -->
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="d-flex justify-content-between">
            <div>
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Device Management /</span> Device List</h4>
            </div>
            <div class="mt-3">
                <!-- Button trigger modal -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('device-create')): ?>
                    <a href="<?php echo e(route('devices.create')); ?>" class="btn btn-primary">Create Device</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <h5 class="card-header">Device List</h5>
            <div class="table-responsive text-nowrap">
                <div class="container">
                    <table class="table devices-ajax-datatable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Device Name</th>
                                <th>Health</th>
                                <th>Status</th>
                                <th>Manager</th>
                                <th>Assinged To</th>
                                <th>Location</th>
                                <th>Created At</th>
                                <th>Api Key</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="assignDevice" data-backdrop="static">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('devices.device-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\iot_web\iot_web\resources\views/devices/index.blade.php ENDPATH**/ ?>